## Use Case:
 This document details how to access the API for currency rate exchanges.
 Convert to a currency amount from multiple other currencies