This is a sample Getting Started page
-------------------------------------------

## Requirements:
- JDK 1.8
- Maven 3.x
- Anypoint Studio 4.2.x


Tests in the examples will open ports while they run, like 8080, so watch out for potential conflicts. 

## Install
To build and run tests run:

    mvn clean install


## Runtime
To access the API...

Dev Env:

Get: https://dev-reef-exp-api-exchange-rates.us-w2.cloudhub.io/api/currencyExchRate


Qa Env:

Get: https://qa-reef-exp-api-exchange-rates.us-w2.cloudhub.io/api/currencyExchRate


## Conclusion
 This document details how to access the API for currency rate exchanges
 
